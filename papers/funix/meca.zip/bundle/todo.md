Should breakable false over the todo

Better images in static
